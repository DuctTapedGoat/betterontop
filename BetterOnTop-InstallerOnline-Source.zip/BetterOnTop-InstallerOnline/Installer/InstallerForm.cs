using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading.Tasks;

namespace BetterOnTopInstaller
{
    public class InstallerForm : Form
    {
        private Button _installButton;
        private Label _statusLabel;
        private ProgressBar _progressBar;
        private TextBox _infoBox;

        public InstallerForm()
        {
            this.Text = "BetterOnTop Online Installer";
            this.Size = new Size(500, 450);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;

            _statusLabel = new Label
            {
                Text = "BetterOnTop - Online Setup",
                Font = new Font(this.Font, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(460, 25),
                TextAlign = ContentAlignment.MiddleCenter
            };

            _infoBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                Location = new Point(20, 50),
                Size = new Size(460, 200),
                Text = "Welcome to the BetterOnTop Online Installer.\r\n\r\n" +
                       "This version is lightweight and will ensure .NET 8 is installed on your system.\r\n\r\n" +
                       "🛠️ HOTKEYS (Ctrl + Alt + ...)\r\n" +
                       "-----------------------------------\r\n" +
                       "• [T] : Toggle 'Topmost' state (Stay on top of everything)\r\n" +
                       "• [W] : Toggle Opacity (Make any window see-through)\r\n" +
                       "• [G] : Toggle Click-through (Interact with windows behind it)\r\n\r\n" +
                       "The installer will now verify and install the .NET 8 Runtime using Winget (Windows Package Manager). " +
                       "A command window will appear to show you the progress of the download and installation."
            };

            _progressBar = new ProgressBar
            {
                Location = new Point(20, 270),
                Size = new Size(460, 25),
                Visible = false
            };

            _installButton = new Button
            {
                Text = "Start Installation",
                Location = new Point(175, 330),
                Size = new Size(150, 45)
            };
            _installButton.Click += Install_Click;

            this.Controls.Add(_statusLabel);
            this.Controls.Add(_infoBox);
            this.Controls.Add(_progressBar);
            this.Controls.Add(_installButton);
        }

        private async void Install_Click(object? sender, EventArgs e)
        {
            _installButton.Enabled = false;
            _progressBar.Visible = true;
            _progressBar.Style = ProgressBarStyle.Marquee;
            _statusLabel.Text = "Installing Dependencies...";

            try
            {
                // Attempt to install .NET 8 via winget VISIBLY
                await Task.Run(() => {
                    try {
                        ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c title .NET 8 Runtime Setup && winget install Microsoft.DotNet.DesktopRuntime.8 --accept-package-agreements --accept-source-agreements && pause") {
                            CreateNoWindow = false,
                            UseShellExecute = true,
                            WindowStyle = ProcessWindowStyle.Normal
                        };
                        var proc = Process.Start(psi);
                        proc?.WaitForExit();
                    } catch (Exception ex) { 
                        // If winget fails, we'll still try to extract the app, but alert the user
                        MessageBox.Show("Could not launch Winget for .NET installation. Please ensure you have the .NET 8 Desktop Runtime installed.\n\nError: " + ex.Message, "Dependency Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                });

                _statusLabel.Text = "Extracting Application...";
                string targetDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BetterOnTop");
                if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);

                string targetExe = Path.Combine(targetDir, "BetterOnTop.exe");

                // Check if running
                var existingProcs = Process.GetProcessesByName("BetterOnTop");
                foreach (var p in existingProcs) {
                    try { p.Kill(); p.WaitForExit(); } catch { }
                }

                // Extract resource
                using (Stream? resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AppBinary"))
                {
                    if (resourceStream == null) throw new Exception("Could not find embedded application binary.");
                    using (FileStream fileStream = new FileStream(targetExe, FileMode.Create))
                    {
                        await resourceStream.CopyToAsync(fileStream);
                    }
                }

                _statusLabel.Text = "Finalizing...";
                
                // Add to startup
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null) key.SetValue("BetterOnTop", "\"" + targetExe + "\"");
                }

                _progressBar.Style = ProgressBarStyle.Blocks;
                _progressBar.Value = 100;
                _statusLabel.Text = "Installation Complete!";
                _infoBox.Text = "BetterOnTop successfuly installed!\r\n\r\n" +
                                "Location: " + targetExe + "\r\n\r\n" +
                                "Instructions:\r\n" +
                                "1. Access it from the System Tray (look for the Shield icon)\r\n" +
                                "2. Use Ctrl+Alt+T, W, or G on any active window.\r\n" +
                                "3. BetterOnTop is now set to launch automatically with Windows.\r\n\r\n" +
                                "Note: If you didn't see the .NET runtime install properly in the CMD window, the app may not launch.";
                
                _installButton.Text = "Launch & Exit";
                _installButton.Enabled = true;
                _installButton.Click -= Install_Click;
                _installButton.Click += (s, ev) => {
                    try { Process.Start(new ProcessStartInfo(targetExe) { UseShellExecute = true }); } catch { }
                    Application.Exit();
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show("Installation failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                _statusLabel.Text = "Installation Failed";
                _installButton.Enabled = true;
            }
        }
    }
}
