using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;
using System.Linq;

namespace BetterOnTop
{
    public class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Application.Run(new BetterOnTopContext());
        }
    }

    public class BetterOnTopContext : ApplicationContext
    {
        private NotifyIcon _trayIcon;
        private BetterOnTopWindow _hiddenWindow;
        private HashSet<IntPtr> _trackedWindows = new HashSet<IntPtr>();
        private WindowPositionManager _posManager;
        private DebugConsoleManager _debugManager;

        public BetterOnTopContext()
        {
            try
            {
                _posManager = new WindowPositionManager();
                _debugManager = new DebugConsoleManager();

                _hiddenWindow = new BetterOnTopWindow(_posManager, _debugManager);
                _hiddenWindow.WindowChanged += OnWindowChanged;
                _hiddenWindow.MouseLockToggled += ToggleMouseLock;

                _trayIcon = new NotifyIcon
                {
                    Text = "BetterOnTop v1.2.2",
                    Icon = SystemIcons.Shield, 
                    ContextMenuStrip = new ContextMenuStrip(),
                    Visible = true
                };
                
                _trayIcon.ContextMenuStrip.Opening += (s, e) => {
                    UpdateMenu();
                    e.Cancel = false;
                };
                
                UpdateMenu();
                
                _trayIcon.ShowBalloonTip(3000, "BetterOnTop v1.2.2", "Hotkeys Active.\nCtrl+Alt+T/W/U/L/M\nCtrl+Alt+/ (Debug Overlay)", ToolTipIcon.Info);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Startup Error: {ex.Message}");
            }
        }

        private IntPtr _mouseLockedHWnd = IntPtr.Zero;
        private System.Windows.Forms.Timer _lockEnforcementTimer;

        private void OnWindowChanged(IntPtr hWnd)
        {
            if (hWnd != IntPtr.Zero)
            {
                _trackedWindows.Add(hWnd);
                UpdateMenu();
                WindowHelper.GetWindowThreadProcessId(hWnd, out uint pid);
                var status = WindowHelper.GetWindowStatus(hWnd);
                var rawStyle = WindowHelper.GetWindowLongPtr(hWnd, -20); // GWL_EXSTYLE
                bool m = hWnd == _mouseLockedHWnd;

                _debugManager.Log($"Window Context: {WindowHelper.GetWindowTitle(hWnd)} (PID: {pid})");
                _debugManager.Log($" -> Handle: 0x{hWnd.ToInt64():X}");
                _debugManager.Log($" -> StyleEx: 0x{rawStyle.ToInt64():X8}");
                _debugManager.Log($" -> Flags: [T:{status.IsTopmost} W:{status.IsLayered} U:{status.IsTransparent} M:{(m ? "1" : "0")}]");
            }
        }

        private void ToggleMouseLock(IntPtr hWnd)
        {
            if (_mouseLockedHWnd == hWnd)
            {
                _mouseLockedHWnd = IntPtr.Zero;
                WindowHelper.ClipCursor(IntPtr.Zero);
                if (_lockEnforcementTimer != null) _lockEnforcementTimer.Stop();
                _debugManager.Log("Mouse Freed");
            }
            else
            {
                _mouseLockedHWnd = hWnd;
                if (_lockEnforcementTimer == null)
                {
                    _lockEnforcementTimer = new System.Windows.Forms.Timer { Interval = 100 };
                    _lockEnforcementTimer.Tick += (s, e) => EnforceMouseLock();
                }
                _lockEnforcementTimer.Start();
                _debugManager.Log($"Mouse Locked to: {WindowHelper.GetWindowTitle(hWnd)}");
            }
            UpdateMenu();
        }

        private void EnforceMouseLock()
        {
            if (_mouseLockedHWnd == IntPtr.Zero)
            {
                _lockEnforcementTimer?.Stop();
                return;
            }

            if (WindowHelper.GetForegroundWindow() == _mouseLockedHWnd)
            {
                if (WindowHelper.GetWindowRect(_mouseLockedHWnd, out var rect))
                {
                    // Constrain with an 8px internal barrier
                    rect.Left += 8;
                    rect.Top += 8;
                    rect.Right -= 8;
                    rect.Bottom -= 8;
                    WindowHelper.ClipCursor(ref rect);
                }
            }
            else
            {
                // Release if window lost focus, but keep the timer running to re-lock when it regains focus
                WindowHelper.ClipCursor(IntPtr.Zero);
            }
        }

        private ToolStripMenuItem CreateRunAtStartupMenuItem()
        {
            var item = new ToolStripMenuItem("Run at Startup");
            item.Checked = IsRunAtStartupEnabled();
            item.Click += (s, e) => {
                bool enabled = !item.Checked;
                SetRunAtStartup(enabled);
                item.Checked = enabled;
            };
            return item;
        }

        private bool IsRunAtStartupEnabled()
        {
            using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false))
            {
                return key?.GetValue("BetterOnTop") != null;
            }
        }

        private void SetRunAtStartup(bool enabled)
        {
            using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
            {
                if (key == null) return;
                if (enabled)
                    key.SetValue("BetterOnTop", $"\"{Application.ExecutablePath}\"");
                else
                    key.DeleteValue("BetterOnTop", false);
            }
        }

        private void UpdateMenu()
        {
            try
            {
                var menu = _trayIcon?.ContextMenuStrip;
                if (menu == null) return;
                menu.Items.Clear();

                // --- Configuration ---
                menu.Items.Add(CreateRunAtStartupMenuItem());
                menu.Items.Add(new ToolStripLabel("BetterOnTop v1.2.2 Active") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 7, FontStyle.Italic) });
                menu.Items.Add(new ToolStripSeparator());

                // --- Modified Windows (T/W/U) ---
                var openTracked = _trackedWindows.Where(h => WindowHelper.GetWindowTitle(h) != "Unknown Window").ToList();
                if (openTracked.Count > 0)
                {
                    menu.Items.Add(new ToolStripLabel("Modified Windows:") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Bold) });
                    foreach (var hWnd in openTracked)
                    {
                        var status = WindowHelper.GetWindowStatus(hWnd);
                        bool isLocked = _posManager.IsRemembered(hWnd);
                        string title = WindowHelper.GetWindowTitle(hWnd);
                        
                        string t = status.IsTopmost ? "T" : "·";
                        string w = status.IsLayered ? "W" : "·";
                        string u = status.IsTransparent ? "U" : "·";
                        string l = isLocked ? "L" : "·";
                        string m = hWnd == _mouseLockedHWnd ? "M" : "·";
                        
                        var item = new ToolStripMenuItem($"[{t}{w}{u}{l}{m}] {title}");
                        var resetItem = new ToolStripMenuItem("Reset All Effects", null, (s, e) => {
                            WindowHelper.ResetWindow(hWnd);
                            _trackedWindows.Remove(hWnd);
                            _debugManager.Log($"Effects Reset for: {title}");
                            UpdateMenu();
                        });
                        item.DropDownItems.Add(resetItem);
                        menu.Items.Add(item);
                    }
                    menu.Items.Add("Reset All Modified", null, (s, e) => {
                        foreach (var hWnd in openTracked) WindowHelper.ResetWindow(hWnd);
                        _trackedWindows.Clear();
                        _debugManager.Log("All Modifications Cleared");
                        UpdateMenu();
                    });
                    menu.Items.Add(new ToolStripSeparator());
                }

                // --- Active Remembered Windows (L) ---
                var activeLocked = _posManager.GetActiveRememberedWindows();
                if (activeLocked.Count > 0)
                {
                    menu.Items.Add(new ToolStripLabel("Active Saved Positions:") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Bold) });
                    foreach (var (title, key, hWnd) in activeLocked)
                    {
                        var item = new ToolStripMenuItem($"[L] {title}");
                        var forgetItem = new ToolStripMenuItem("Stop Remembering", null, (s, e) => {
                            _posManager.ForgetWindow(key);
                        });
                        item.DropDownItems.Add(forgetItem);
                        menu.Items.Add(item);
                    }
                    menu.Items.Add("Forget All Positions", null, (s, e) => {
                        if (MessageBox.Show("Delete ALL saved positions?", "BetterOnTop", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            _posManager.ClearAll();
                        }
                    });
                    menu.Items.Add(new ToolStripSeparator());
                }

                if (openTracked.Count == 0 && activeLocked.Count == 0)
                {
                    menu.Items.Add(new ToolStripMenuItem("No Active Modifications") { Enabled = false });
                    menu.Items.Add(new ToolStripSeparator());
                }

                menu.Items.Add("Exit BetterOnTop", null, (s, e) => ExitThread());
            }
            catch (Exception ex)
            {
                _debugManager.Log($"Menu Load Error: {ex.Message}");
                var menu = _trayIcon?.ContextMenuStrip;
                if (menu == null) return;
                menu.Items.Clear();
                menu.Items.Add(new ToolStripMenuItem("Menu Load Error") { Enabled = false });
                menu.Items.Add("Exit BetterOnTop", null, (s, e) => ExitThread());
            }
        }

        protected override void ExitThreadCore()
        {
            _debugManager.Log("Application Exiting...");
            foreach (var hWnd in _trackedWindows) WindowHelper.ResetWindow(hWnd);
            _trackedWindows.Clear();

            if (_trayIcon != null) _trayIcon.Visible = false;
            _hiddenWindow.Dispose();
            _posManager.Dispose();
            base.ExitThreadCore();
        }
    }

    public class BetterOnTopWindow : NativeWindow, IDisposable
    {
        private const int WM_HOTKEY = 0x0312;
        private const int HOTKEY_ID_T = 0x1001;
        private const int HOTKEY_ID_W = 0x1002;
        private const int HOTKEY_ID_U = 0x1003;
        private const int HOTKEY_ID_L = 0x1004;
        private const int HOTKEY_ID_D = 0x1005;
        private const int HOTKEY_ID_C = 0x1006;
        private const int HOTKEY_ID_S = 0x1007;
        private const int HOTKEY_ID_M = 0x1008;

        private WindowPositionManager _posManager;
        private DebugConsoleManager _debugManager;

        public event Action<IntPtr>? WindowChanged;
        public event Action<IntPtr>? MouseLockToggled;

        public BetterOnTopWindow(WindowPositionManager posManager, DebugConsoleManager debugManager)
        {
            _posManager = posManager;
            _debugManager = debugManager;
            CreateHandle(new CreateParams { Caption = "BetterOnTopProcessorV1_2" });
            
            uint modifiers = WindowHelper.MOD_CONTROL | WindowHelper.MOD_ALT;
            uint debugMods = modifiers | WindowHelper.MOD_SHIFT;
            
            bool r1 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_T, modifiers, 0x54); // T
            bool r2 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_W, modifiers, 0x57); // W
            bool r3 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_U, modifiers, 0x55); // U
            bool r4 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_L, modifiers, 0x4C); // L
            bool r5 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_D, modifiers, 0xBF); // /
            bool r6 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_C, modifiers, 0x08); // Backspace
            bool r7 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_S, modifiers, 0xDC); // \
            bool r8 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_M, modifiers, 0x4D); // M

            if (r1 && r2 && r3 && r4 && r5 && r6 && r7 && r8)
            {
                SystemSounds.Hand.Play(); 
            }
            else
            {
                SystemSounds.Exclamation.Play(); 
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY)
            {
                int id = m.WParam.ToInt32();
                if (id == HOTKEY_ID_D)
                {
                    Console.Beep(800, 100); // Specific chirp for Debug
                    _debugManager.ToggleDebugConsoleForForeground();
                    return;
                }
                if (id == HOTKEY_ID_C)
                {
                    _debugManager.ClearLog();
                    return;
                }
                if (id == HOTKEY_ID_S)
                {
                    _debugManager.SaveLogsToFile();
                    return;
                }

                IntPtr hWnd = WindowHelper.GetForegroundWindow();
                if (hWnd != IntPtr.Zero)
                {
                    SystemSounds.Asterisk.Play();
                    string title = WindowHelper.GetWindowTitle(hWnd);
                    
                    if (id == HOTKEY_ID_T) 
                    {
                        WindowHelper.ToggleTopmost(hWnd);
                        _debugManager.Log($"Toggle TOPMOST for: {title}");
                    }
                    else if (id == HOTKEY_ID_W) 
                    {
                        WindowHelper.ToggleOpacity(hWnd);
                        _debugManager.Log($"Toggle OPACITY for: {title}");
                    }
                    else if (id == HOTKEY_ID_U) 
                    {
                        WindowHelper.ToggleClickthrough(hWnd);
                        _debugManager.Log($"Toggle GHOST for: {title}");
                    }
                    else if (id == HOTKEY_ID_L) 
                    {
                        _posManager.ToggleMemory(hWnd);
                        _debugManager.Log($"Toggle MEMORY for: {title}");
                    }
                    else if (id == HOTKEY_ID_M)
                    {
                        MouseLockToggled?.Invoke(hWnd);
                    }
                    
                    WindowChanged?.Invoke(hWnd);
                }
            }
            base.WndProc(ref m);
        }

        public void Dispose()
        {
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_T);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_W);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_U);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_L);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_D);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_C);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_S);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_M);
            DestroyHandle();
        }
    }
}
