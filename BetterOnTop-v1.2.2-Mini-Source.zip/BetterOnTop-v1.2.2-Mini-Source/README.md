# 🛡️ BetterOnTop v1.2 (DEBUG EDITION)

The ultimate overkill debugging version of BetterOnTop.

---

## 🚀 The Debug Specialty Toggle

Use **`Ctrl + Alt + /`** to summon the **Debug Logcat Overlay**.

### Overkill Features

- **TUI Logcat Backend**: A live console appears showing every window context change and hotkey trigger.
- **Auto-Follow GUI**: The console window **tracks the foreground window** in real-time. It will overlay itself at the top of whatever window you are currently modifying.
- **Recursive Effects**: The debug console itself is:
  - **Always On Top**
  - **Transparent** (Opacity 200)
  - **Click-through** (You can click right through the logs to the window behind it).

---

## ⚡ Core Hotkeys (Same as v1.1)

| Key | Action | Description |
|:---:|:---|:---|
| **`T`** | **Topmost** | Pins window to stay on top. |
| **`W`** | **Opacity** | Toggles transparency. |
| **`U`** | **Unlock (Ghost)** | Enables click-through mode. |
| **`L`** | **Lock Position** | Continuous X/Y memory. |

---

## 🛠️ Internal Mechanics

- **AllocConsole**: Dynamically spawns a console from a hidden process.
- **WindowPlacement Tracking**: Uses high-frequency polling (30ms) to ensure the console stays glued to your active window.
- **Shield Icon**: Same trusted tray icon.

Built for fun. Overkill? Absolutely. 🛠️🔥
