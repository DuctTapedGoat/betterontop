using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Drawing;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;

namespace BetterOnTop
{
    public class DebugConsoleManager : IDisposable
    {
        private GhostOverlayForm _overlayForm;
        private OutlinedLabel _logLabel;
        private bool _isVisible = false;
        private IntPtr _targetHWnd = IntPtr.Zero;
        private WindowHelper.RECT _lastRect;
        private IntPtr _hookId = IntPtr.Zero;
        private IntPtr _mouseHookId = IntPtr.Zero;
        private IntPtr _winEventHook = IntPtr.Zero;
        private WindowHelper.LowLevelKeyboardProc _hookProc;
        private WindowHelper.LowLevelKeyboardProc _mouseHookProc;
        private WindowHelper.WinEventProc _winEventProc;
        private System.Text.StringBuilder _inputBuffer = new System.Text.StringBuilder();
        private System.Windows.Forms.Timer _batchTimer;
        private List<string> _fullLogHistory = new List<string>();
        private System.Collections.Concurrent.ConcurrentQueue<string> _logQueue = new System.Collections.Concurrent.ConcurrentQueue<string>();
        private System.Windows.Forms.Timer _uiUpdateTimer;

        public DebugConsoleManager()
        {
            _hookProc = HookCallback;
            _mouseHookProc = MouseHookCallback;
            _winEventProc = WinEventCallback;
            
            _batchTimer = new System.Windows.Forms.Timer { Interval = 10000 };
            _batchTimer.Tick += (s, e) => FlushInputBuffer();

            _uiUpdateTimer = new System.Windows.Forms.Timer { Interval = 100 };
            _uiUpdateTimer.Tick += (s, e) => ProcessLogQueue();
            _uiUpdateTimer.Start();

            InitializeOverlay();
        }

        private void InitializeOverlay()
        {
            _overlayForm = new GhostOverlayForm();
            
            _logLabel = new OutlinedLabel
            {
                Dock = DockStyle.Fill,
                AutoSize = false,
                Font = new Font("Consolas", 11, FontStyle.Bold),
                OutlineColor = Color.Black, // Fully opaque black outline
                OutlineWidth = 2,
                ForeColor = Color.Cyan, // Fully opaque Cyan text
                Text = "GLΔSS HUD READY\n",
                BackColor = Color.Transparent,
                Padding = new Padding(10)
            };

            _overlayForm.Controls.Add(_logLabel);
        }

        public void ToggleDebugConsoleForForeground()
        {
            if (!_isVisible)
            {
                _targetHWnd = WindowHelper.GetForegroundWindow();
                if (_targetHWnd == IntPtr.Zero) return;

                _isVisible = true;
                _overlayForm.Show();
                StartHooks();
                _batchTimer.Start();
                _uiUpdateTimer.Start();
                _ = TrackPositionLoop();
                Log("HUD ENGAGED");
            }
            else
            {
                _isVisible = false;
                try
                {
                    _batchTimer.Stop();
                    _uiUpdateTimer.Stop();
                    StopHooks();
                    if (_overlayForm != null && !_overlayForm.IsDisposed)
                    {
                        _overlayForm.Hide();
                    }
                }
                catch { /* Ignore deactivation glitches */ }
                
                _targetHWnd = IntPtr.Zero;
                _fullLogHistory.Clear();
                _logLabel.Text = "";
            }
        }

        public void ClearLog()
        {
            if (_isVisible)
            {
                _logLabel.Text = "--- Clear ---\n";
                _fullLogHistory.Clear();
            }
        }

        public void SaveLogsToFile()
        {
            try
            {
                string path = System.IO.Path.Combine(AppDomain.CurrentDomain.BaseDirectory, $"BetterOnTop_Log_{DateTime.Now:yyyyMMdd_HHmm}.txt");
                System.IO.File.WriteAllLines(path, _fullLogHistory);
                Log($"Logs Saved: {System.IO.Path.GetFileName(path)}");
                System.Media.SystemSounds.Exclamation.Play();
            }
            catch (Exception ex)
            {
                Log($"Save Error: {ex.Message}");
            }
        }

        public void Log(string message, bool includeTimestamp = true)
        {
            if (!_isVisible) return;
            string entry = includeTimestamp ? $"[{DateTime.Now:HH:mm:ss}] {message}" : $"> {message}";
            _logQueue.Enqueue(entry);
        }

        private void ProcessLogQueue()
        {
            if (!_isVisible || _logQueue.IsEmpty) return;

            bool changed = false;
            while (_logQueue.TryDequeue(out string? entry))
            {
                if (entry == null) continue;
                _fullLogHistory.Add(entry);
                changed = true;
            }

            if (changed)
            {
                if (_fullLogHistory.Count > 150) 
                    _fullLogHistory.RemoveRange(0, _fullLogHistory.Count - 150);

                var displayLines = _fullLogHistory.AsEnumerable().Reverse().Take(80);
                _logLabel.Text = string.Join("\n", displayLines);
                _logLabel.Invalidate(); // Force repaint of the label
            }
        }

        private void StartHooks()
        {
            if (_hookId == IntPtr.Zero && _targetHWnd != IntPtr.Zero)
            {
                try 
                {
                    // Use GetModuleHandle(null) to get the current executable's handle
                    IntPtr hMod = WindowHelper.GetModuleHandle(null);
                    
                    _hookId = WindowHelper.SetWindowsHookExW(WindowHelper.WH_KEYBOARD_LL, _hookProc, hMod, 0);
                    _mouseHookId = WindowHelper.SetWindowsHookExW(WindowHelper.WH_MOUSE_LL, _mouseHookProc, hMod, 0);

                    // Track UI activity for the target process
                    uint processId = 0;
                    WindowHelper.GetWindowThreadProcessId(_targetHWnd, out processId);
                    
                    // SAFETY: Never hook into our own process to avoid 'Debug-The-Debug' recursion.
                    uint currentPid = (uint)Environment.ProcessId;
                    if (processId != 0 && processId != currentPid)
                    {
                        _winEventHook = WindowHelper.SetWinEventHook(EVENT_OBJECT_FOCUS, EVENT_OBJECT_VALUECHANGE, IntPtr.Zero, _winEventProc, processId, 0, WINEVENT_OUTOFCONTEXT);
                    }
                }
                catch (Exception ex)
                {
                    // If hooks fail, we MUST stay disabled to avoid crashing the shell
                    _isVisible = false;
                    Log($"Hook Error: {ex.Message}");
                    StopHooks();
                }
            }
        }

        private const uint EVENT_OBJECT_FOCUS = 0x8005;
        private const uint EVENT_OBJECT_NAMECHANGE = 0x800C;
        private const uint EVENT_OBJECT_VALUECHANGE = 0x800E;
        private const uint WINEVENT_OUTOFCONTEXT = 0;

        private void StopHooks()
        {
            if (_hookId != IntPtr.Zero)
            {
                WindowHelper.UnhookWindowsHookEx(_hookId);
                _hookId = IntPtr.Zero;
            }
            if (_mouseHookId != IntPtr.Zero)
            {
                WindowHelper.UnhookWindowsHookEx(_mouseHookId);
                _mouseHookId = IntPtr.Zero;
            }
            if (_winEventHook != IntPtr.Zero)
            {
                WindowHelper.UnhookWinEvent(_winEventHook);
                _winEventHook = IntPtr.Zero;
            }
        }

        private void WinEventCallback(IntPtr hWinEventHook, uint eventType, IntPtr hWnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
        {
            if (_isVisible && _targetHWnd != IntPtr.Zero)
            {
                // We only care about name changes or focus changes in the target process
                if (eventType == EVENT_OBJECT_NAMECHANGE) Log("[UI:NameUpdate]");
                else if (eventType == EVENT_OBJECT_FOCUS) Log("[UI:FocusChange]");
                else if (eventType == EVENT_OBJECT_VALUECHANGE) Log("[UI:StateUpdate]");
            }
        }

        private IntPtr HookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0 && (wParam == (IntPtr)WindowHelper.WM_KEYDOWN || wParam == (IntPtr)WindowHelper.WM_SYSKEYDOWN))
            {
                try 
                {
                    // QUICK EXIT: If we aren't visible or not the target, don't process anything
                    if (!_isVisible || _targetHWnd == IntPtr.Zero || WindowHelper.GetForegroundWindow() != _targetHWnd)
                        return WindowHelper.CallNextHookEx(_hookId, nCode, wParam, lParam);

                    uint vkCode = (uint)Marshal.ReadInt32(lParam);
                    uint scanCode = WindowHelper.MapVirtualKeyW(vkCode, 0);
                    
                    byte[] keyState = new byte[256];
                    if ((WindowHelper.GetKeyState(0x10) & 0x80) != 0) keyState[0x10] = 0x80; // Shift
                    if ((WindowHelper.GetKeyState(0x11) & 0x80) != 0) keyState[0x11] = 0x80; // Control
                    if ((WindowHelper.GetKeyState(0x12) & 0x80) != 0) keyState[0x12] = 0x80; // Alt
                    if ((WindowHelper.GetKeyState(0x14) & 0x01) != 0) keyState[0x14] = 0x01; // Caps

                    char[] buffer = new char[10];
                    int result = WindowHelper.ToUnicode(vkCode, scanCode, keyState, buffer, buffer.Length, 0);

                    string readable = "";
                    if (result > 0)
                    {
                        readable = new string(buffer, 0, result);
                    }
                    else if (result < 0)
                    {
                        readable = ""; // Dead key
                    }
                    else
                    {
                        readable = MapSpecialKey((Keys)vkCode);
                    }
                    
                    if (!string.IsNullOrEmpty(readable))
                    {
                        lock (_inputBuffer)
                        {
                            _inputBuffer.Append(readable);
                        }
                    }
                }
                catch { /* Minimal overhead for hook errors */ }
            }
            return WindowHelper.CallNextHookEx(_hookId, nCode, wParam, lParam);
        }

        private string MapSpecialKey(Keys key)
        {
            switch (key)
            {
                case Keys.Enter: return "↵\n"; 
                case Keys.Back: return "⌫";
                case Keys.Tab: return "⇥";
                case Keys.LShiftKey: case Keys.RShiftKey: return "⇧";
                case Keys.LControlKey: case Keys.RControlKey: return "^";
                case Keys.LMenu: case Keys.RMenu: return "⌥";
                default: return ""; 
            }
        }

        private IntPtr MouseHookCallback(int nCode, IntPtr wParam, IntPtr lParam)
        {
            if (nCode >= 0)
            {
                string msg = "";
                if (wParam == (IntPtr)WindowHelper.WM_LBUTTONDOWN) msg = "[LMB]";
                else if (wParam == (IntPtr)WindowHelper.WM_RBUTTONDOWN) msg = "[RMB]";
                else if (wParam == (IntPtr)WindowHelper.WM_MBUTTONDOWN) msg = "[MMB]";

                if (msg != "" && _isVisible && _targetHWnd != IntPtr.Zero)
                {
                    if (WindowHelper.GetForegroundWindow() == _targetHWnd)
                    {
                        Log(msg);
                    }
                }
            }
            return WindowHelper.CallNextHookEx(_mouseHookId, nCode, wParam, lParam);
        }

        private void FlushInputBuffer()
        {
            string gathered;
            lock (_inputBuffer)
            {
                if (_inputBuffer.Length == 0) return;
                gathered = _inputBuffer.ToString();
                _inputBuffer.Clear();
            }
            Log(gathered, false);
        }

        private async Task TrackPositionLoop()
        {
            while (_isVisible && _targetHWnd != IntPtr.Zero)
            {
                try
                {
                    if (!WindowHelper.IsWindowVisible(_targetHWnd))
                    {
                        ToggleDebugConsoleForForeground();
                        break;
                    }

                    if (WindowHelper.GetWindowRect(_targetHWnd, out var rect))
                    {
                        // Check if minimized (Win32 reports -32000 for minimized windows)
                        if (rect.Left < -30000)
                        {
                            _overlayForm.Hide();
                        }
                        else
                        {
                            if (!_overlayForm.Visible) _overlayForm.Show();

                            if (rect.Left != _lastRect.Left || rect.Top != _lastRect.Top || rect.Width != _lastRect.Width || rect.Height != _lastRect.Height)
                            {
                                _lastRect = rect;
                                
                                // Enhanced logic: if the target is roughly fullscreen, use display bounds
                                Screen screen = Screen.FromHandle(_targetHWnd);
                                int x = rect.Left;
                                int y = rect.Top;
                                int w = rect.Width;
                                int h = rect.Height;

                                if (w >= screen.Bounds.Width - 10 && h >= screen.Bounds.Height - 10)
                                {
                                    x = screen.Bounds.X + 2;
                                    y = screen.Bounds.Y + 2;
                                    w = screen.Bounds.Width - 4;
                                    h = screen.Bounds.Height - 4;
                                }
                                else
                                {
                                    x += 2; y += 2; w -= 4; h -= 4;
                                }

                                WindowHelper.SetWindowPos(_overlayForm.Handle, WindowHelper.HWND_TOPMOST,
                                    x, y, w, h,
                                    WindowHelper.SWP_NOACTIVATE | WindowHelper.SWP_NOOWNERZORDER | WindowHelper.SWP_NOSENDCHANGING);
                            }
                        }
                    }
                }
                catch { break; }
                await Task.Delay(100); // 10Hz is plenty for HUD tracking
            }
        }

        public void Dispose()
        {
            StopHooks();
            _batchTimer?.Dispose();
            _uiUpdateTimer?.Dispose();
            _overlayForm?.Dispose();
        }
    }

    public class GhostOverlayForm : Form
    {
        public GhostOverlayForm()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.Text = "BetterOnTop Glass Overlay";
            
            // Text-Only HUD: Set TransparencyKey to the background color
            Color transColor = Color.FromArgb(10, 10, 10);
            this.BackColor = transColor;
            this.TransparencyKey = transColor;
            
            this.AllowTransparency = true;
            this.Opacity = 0.5; // 50% transparency for the floating text
            this.DoubleBuffered = true;
            this.ShowInTaskbar = false;
        }

        protected override bool ShowWithoutActivation => true;

        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams cp = base.CreateParams;
                // WS_EX_TOPMOST (0x00000008)
                // WS_EX_TRANSPARENT (0x00000020)
                // WS_EX_LAYERED (0x00080000)
                // WS_EX_NOACTIVATE (0x08000000)
                cp.ExStyle |= 0x00000008 | 0x00000020 | 0x00080000 | 0x08000000;
                return cp;
            }
        }
    }

    public class OutlinedLabel : Label
    {
        public Color OutlineColor { get; set; } = Color.Black;
        public int OutlineWidth { get; set; } = 2;

        public OutlinedLabel()
        {
            DoubleBuffered = true;
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            if (string.IsNullOrEmpty(Text)) return;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            e.Graphics.TextRenderingHint = System.Drawing.Text.TextRenderingHint.ClearTypeGridFit;

            using (var gp = new System.Drawing.Drawing2D.GraphicsPath())
            using (var outlinePen = new Pen(OutlineColor, OutlineWidth))
            using (var textBrush = new SolidBrush(ForeColor))
            {
                float emSize = e.Graphics.DpiY * Font.SizeInPoints / 72;
                gp.AddString(Text, Font.FontFamily, (int)Font.Style, emSize, 
                    new Rectangle(Padding.Left, Padding.Top, Width - Padding.Horizontal, Height - Padding.Vertical), 
                    StringFormat.GenericDefault);

                e.Graphics.DrawPath(outlinePen, gp);
                e.Graphics.FillPath(textBrush, gp);
            }
        }
    }
}
