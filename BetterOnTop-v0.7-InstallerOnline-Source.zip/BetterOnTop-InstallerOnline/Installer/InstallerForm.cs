using System;
using System.Drawing;
using System.IO;
using System.Reflection;
using System.Windows.Forms;
using Microsoft.Win32;
using System.Diagnostics;
using System.Threading.Tasks;
using System.Linq;

namespace BetterOnTopInstaller
{
    public class InstallerForm : Form
    {
        private Button _installButton;
        private Label _statusLabel;
        private ProgressBar _progressBar;
        private TextBox _infoBox;

        public InstallerForm()
        {
            this.Text = "BetterOnTop Online Installer";
            this.Size = new Size(500, 450);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;

            _statusLabel = new Label
            {
                Text = "BetterOnTop - Online Setup",
                Font = new Font(this.Font, FontStyle.Bold),
                Location = new Point(20, 20),
                Size = new Size(460, 25),
                TextAlign = ContentAlignment.MiddleCenter
            };

            _infoBox = new TextBox
            {
                Multiline = true,
                ReadOnly = true,
                ScrollBars = ScrollBars.Vertical,
                Location = new Point(20, 50),
                Size = new Size(460, 200),
                Text = "Welcome to the BetterOnTop Online Installer.\r\n\r\n" +
                       "This version is lightweight and will ensure .NET 8 is installed on your system.\r\n\r\n" +
                       "🚀 HOTKEYS (Ctrl + Alt + ...)\r\n" +
                       "-----------------------------------\r\n" +
                       "• [T] : Toggle 'Topmost' state (Stay Always on Top)\r\n" +
                       "• [W] : Toggle Opacity (Make windows transparent)\r\n" +
                       "• [G] : Toggle Click-through (Interact with windows behind)\r\n\r\n" +
                       "The installer will now verify and install the .NET 8 Runtime using Winget (Windows Package Manager). " +
                       "A command window will appear to show you the progress. " +
                       "BetterOnTop will be registered as a Windows application for easy uninstallation later."
            };

            _progressBar = new ProgressBar
            {
                Location = new Point(20, 270),
                Size = new Size(460, 25),
                Visible = false
            };

            _installButton = new Button
            {
                Text = "Install BetterOnTop",
                Location = new Point(175, 330),
                Size = new Size(150, 45)
            };
            _installButton.Click += Install_Click;

            this.Controls.Add(_statusLabel);
            this.Controls.Add(_infoBox);
            this.Controls.Add(_progressBar);
            this.Controls.Add(_installButton);
        }

        private async void Install_Click(object? sender, EventArgs e)
        {
            _installButton.Enabled = false;
            _progressBar.Visible = true;
            _progressBar.Style = ProgressBarStyle.Marquee;
            _statusLabel.Text = "Installing Dependencies...";

            try
            {
                // Attempt to install .NET 8 via winget VISIBLY
                await Task.Run(() => {
                    try {
                        ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", "/c title .NET 8 Runtime Setup && winget install Microsoft.DotNet.DesktopRuntime.8 --accept-package-agreements --accept-source-agreements && pause") {
                            CreateNoWindow = false,
                            UseShellExecute = true,
                            WindowStyle = ProcessWindowStyle.Normal
                        };
                        var proc = Process.Start(psi);
                        proc?.WaitForExit();
                    } catch { /* alert handled in final infoBox note */ }
                });

                _statusLabel.Text = "Setting Up Files...";
                string targetDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BetterOnTop");
                if (!Directory.Exists(targetDir)) Directory.CreateDirectory(targetDir);

                string targetExe = Path.Combine(targetDir, "BetterOnTop.exe");
                string uninstallerExe = Path.Combine(targetDir, "BetterOnTopInstaller.exe");

                // Check if running
                var existingProcs = Process.GetProcessesByName("BetterOnTop");
                foreach (var p in existingProcs) {
                    try { p.Kill(); p.WaitForExit(); } catch { }
                }

                // Extract resource
                using (Stream? resourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream("AppBinary"))
                {
                    if (resourceStream == null) throw new Exception("Could not find embedded application binary.");
                    using (FileStream fileStream = new FileStream(targetExe, FileMode.Create))
                    {
                        await resourceStream.CopyToAsync(fileStream);
                    }
                }

                // Copy this installer for uninstallation support
                File.Copy(Process.GetCurrentProcess().MainModule!.FileName, uninstallerExe, true);

                _statusLabel.Text = "Configuring Autostart & WinAdd/Remove...";
                
                // Add to startup
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null) key.SetValue("BetterOnTop", "\"" + targetExe + "\"");
                }

                // Register Uninstall
                string uninstallKeyPath = @"Software\Microsoft\Windows\CurrentVersion\Uninstall\BetterOnTop";
                using (RegistryKey? key = Registry.CurrentUser.CreateSubKey(uninstallKeyPath))
                {
                    if (key != null)
                    {
                        key.SetValue("DisplayName", "BetterOnTop (Installer)");
                        key.SetValue("UninstallString", "\"" + uninstallerExe + "\" /uninstall");
                        key.SetValue("DisplayIcon", targetExe);
                        key.SetValue("Publisher", "BetterOnTop");
                        key.SetValue("URLInfoAbout", "https://github.com/");
                    }
                }

                _progressBar.Style = ProgressBarStyle.Blocks;
                _progressBar.Value = 100;
                _statusLabel.Text = "Installation Successful!";
                _infoBox.Text = "BetterOnTop successfuly installed!\r\n\r\n" +
                                "The app is now configured to start with Windows. Access it from the system tray (near the clock).\r\n\r\n" +
                                "Uninstalling: You can now remove BetterOnTop via 'Apps & Features' in your Windows Settings at any time.\r\n\r\n" +
                                "Note: If the app fails to launch, please manually install the .NET 8 Desktop Runtime.";
                
                _installButton.Text = "Launch & Exit";
                _installButton.Enabled = true;
                _installButton.Click -= Install_Click;
                _installButton.Click += (s, ev) => {
                    try { Process.Start(new ProcessStartInfo(targetExe) { UseShellExecute = true }); } catch { }
                    Application.Exit();
                };
            }
            catch (Exception ex)
            {
                MessageBox.Show("Installation failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                _statusLabel.Text = "Installation Failed";
                _installButton.Enabled = true;
            }
        }

        public static void PerformUninstall()
        {
            try
            {
                string appData = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BetterOnTop");
                string appExe = Path.Combine(appData, "BetterOnTop.exe");

                // Kill process
                var existingProcs = Process.GetProcessesByName("BetterOnTop");
                foreach (var p in existingProcs) {
                    try { p.Kill(); p.WaitForExit(); } catch { }
                }

                // Remove startup
                using (RegistryKey? key = Registry.CurrentUser.OpenSubKey(@"Software\Microsoft\Windows\CurrentVersion\Run", true))
                {
                    if (key != null) key.DeleteValue("BetterOnTop", false);
                }

                // Remove uninstall registration
                Registry.CurrentUser.DeleteSubKeyTree(@"Software\Microsoft\Windows\CurrentVersion\Uninstall\BetterOnTop", false);

                // Delete files
                if (File.Exists(appExe)) File.Delete(appExe);

                // Self-deletion command
                ProcessStartInfo psi = new ProcessStartInfo("cmd.exe", $"/c timeout /t 2 /nobreak && rmdir /s /q \"{appData}\"") {
                    CreateNoWindow = true,
                    UseShellExecute = false
                };
                Process.Start(psi);

                MessageBox.Show("BetterOnTop has been uninstalled.", "Uninstalled", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Application.Exit();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Uninstallation failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
