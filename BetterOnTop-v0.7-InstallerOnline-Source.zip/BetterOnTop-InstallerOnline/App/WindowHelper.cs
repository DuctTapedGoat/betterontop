using System;
using System.Runtime.InteropServices;

namespace BetterOnTop
{
    public static partial class WindowHelper
    {
        [LibraryImport("user32.dll", SetLastError = true)]
        public static partial IntPtr GetForegroundWindow();

        [LibraryImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);

        [LibraryImport("user32.dll", EntryPoint = "GetWindowLongW", SetLastError = true)]
        private static partial int GetWindowLong32(IntPtr hWnd, int nIndex);

        [LibraryImport("user32.dll", EntryPoint = "GetWindowLongPtrW", SetLastError = true)]
        private static partial IntPtr GetWindowLongPtr64(IntPtr hWnd, int nIndex);

        [LibraryImport("user32.dll", EntryPoint = "SetWindowLongW", SetLastError = true)]
        private static partial int SetWindowLong32(IntPtr hWnd, int nIndex, int dwNewLong);

        [LibraryImport("user32.dll", EntryPoint = "SetWindowLongPtrW", SetLastError = true)]
        private static partial IntPtr SetWindowLongPtr64(IntPtr hWnd, int nIndex, IntPtr dwNewLong);

        [LibraryImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool SetLayeredWindowAttributes(IntPtr hWnd, int crKey, byte bAlpha, int dwFlags);

        [LibraryImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool RegisterHotKey(IntPtr hWnd, int id, uint fsModifiers, uint vk);

        [LibraryImport("user32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool UnregisterHotKey(IntPtr hWnd, int id);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        public static partial bool IsWindowVisible(IntPtr hWnd);

        [LibraryImport("user32.dll", EntryPoint = "GetWindowTextW", StringMarshalling = StringMarshalling.Utf16)]
        private static partial int GetWindowText(IntPtr hWnd, [Out] char[] lpString, int nMaxCount);

        [LibraryImport("user32.dll", EntryPoint = "GetWindowTextLengthW")]
        private static partial int GetWindowTextLength(IntPtr hWnd);

        private const int GWL_EXSTYLE = -20;
        private const int WS_EX_TOPMOST = 0x00000008;
        private const int WS_EX_LAYERED = 0x00080000;
        private const int WS_EX_TRANSPARENT = 0x00000020;
        private const int LWA_ALPHA = 0x00000002;

        public static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        public static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);

        public const uint SWP_NOMOVE = 0x0002;
        public const uint SWP_NOSIZE = 0x0001;
        public const uint SWP_SHOWWINDOW = 0x0040;
        public const uint SWP_FRAMECHANGED = 0x0020;
        public const uint SWP_NOZORDER = 0x0004;
        public const uint SWP_NOACTIVATE = 0x0010;

        public const uint MOD_ALT = 0x0001;
        public const uint MOD_CONTROL = 0x0002;

        public static IntPtr GetWindowLongPtr(IntPtr hWnd, int nIndex)
        {
            if (IntPtr.Size == 8) return GetWindowLongPtr64(hWnd, nIndex);
            return (IntPtr)GetWindowLong32(hWnd, nIndex);
        }

        public static IntPtr SetWindowLongPtr(IntPtr hWnd, int nIndex, IntPtr dwNewLong)
        {
            if (IntPtr.Size == 8) return SetWindowLongPtr64(hWnd, nIndex, dwNewLong);
            return (IntPtr)SetWindowLong32(hWnd, nIndex, (int)dwNewLong);
        }

        private static void UpdateStyle(IntPtr hWnd, long style)
        {
            SetWindowLongPtr(hWnd, GWL_EXSTYLE, (IntPtr)style);
            SetWindowPos(hWnd, IntPtr.Zero, 0, 0, 0, 0, 
                SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED | SWP_NOACTIVATE);
        }

        public static void ToggleTopmost(IntPtr hWnd)
        {
            long style = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
            bool isTopmost = (style & WS_EX_TOPMOST) != 0;

            if (isTopmost)
                SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
            else
                SetWindowPos(hWnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
        }

        public static void ToggleOpacity(IntPtr hWnd, byte alpha = 180)
        {
            long style = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
            bool isLayered = (style & WS_EX_LAYERED) != 0;

            if (isLayered)
            {
                style &= ~WS_EX_LAYERED;
                style &= ~WS_EX_TRANSPARENT; 
                UpdateStyle(hWnd, style);
            }
            else
            {
                style |= WS_EX_LAYERED;
                UpdateStyle(hWnd, style);
                SetLayeredWindowAttributes(hWnd, 0, alpha, LWA_ALPHA);
            }
        }

        public static void ToggleClickthrough(IntPtr hWnd)
        {
            long style = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
            bool isLayered = (style & WS_EX_LAYERED) != 0;
            bool isTransparent = (style & WS_EX_TRANSPARENT) != 0;

            if (isTransparent)
            {
                style &= ~WS_EX_TRANSPARENT;
                UpdateStyle(hWnd, style);
            }
            else if (isLayered)
            {
                style |= WS_EX_TRANSPARENT;
                UpdateStyle(hWnd, style);
            }
        }

        public static void ResetWindow(IntPtr hWnd)
        {
            // Remove Topmost
            SetWindowPos(hWnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
            
            // Remove Layered and Transparent
            long style = GetWindowLongPtr(hWnd, GWL_EXSTYLE).ToInt64();
            style &= ~WS_EX_LAYERED;
            style &= ~WS_EX_TRANSPARENT;
            UpdateStyle(hWnd, style);
        }

        public static string GetWindowTitle(IntPtr hWnd)
        {
            try {
                int length = GetWindowTextLength(hWnd);
                if (length == 0) return "Unknown Window";
                var charArray = new char[length + 1];
                GetWindowText(hWnd, charArray, charArray.Length);
                return new string(charArray).TrimEnd('\0');
            } catch { return "Unknown Window"; }
        }
    }
}
