using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;
using System.Linq;

namespace BetterOnTop
{
    public class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Application.Run(new BetterOnTopContext());
        }
    }

    public class BetterOnTopContext : ApplicationContext
    {
        private NotifyIcon _trayIcon;
        private BetterOnTopWindow _hiddenWindow;
        private HashSet<IntPtr> _trackedWindows = new HashSet<IntPtr>();

        public BetterOnTopContext()
        {
            _hiddenWindow = new BetterOnTopWindow();
            _hiddenWindow.WindowChanged += OnWindowChanged;

            _trayIcon = new NotifyIcon
            {
                Text = "BetterOnTop",
                Icon = SystemIcons.Shield,
                ContextMenuStrip = new ContextMenuStrip(),
                Visible = true
            };
            
            UpdateMenu();
            
            _trayIcon.ShowBalloonTip(3000, "BetterOnTop", "Hotkeys Active.\nCtrl+Alt+T/W/G", ToolTipIcon.Info);
        }

        private void OnWindowChanged(IntPtr hWnd)
        {
            _trackedWindows.Add(hWnd);
            UpdateMenu();
        }

        private void UpdateMenu()
        {
            var menu = _trayIcon.ContextMenuStrip;
            if (menu == null) return;
            menu.Items.Clear();

            if (_trackedWindows.Count > 0)
            {
                menu.Items.Add("Modified Windows:").Enabled = false;
                
                // Copy to list to avoid modification during enumeration
                var windows = _trackedWindows.ToList();
                foreach (var hWnd in windows)
                {
                    string title = WindowHelper.GetWindowTitle(hWnd);
                    if (string.IsNullOrEmpty(title)) title = $"Window {hWnd}";
                    
                    var item = new ToolStripMenuItem($"{title}");
                    var resetItem = new ToolStripMenuItem("Reset Window", null, (s, e) => {
                        WindowHelper.ResetWindow(hWnd);
                        _trackedWindows.Remove(hWnd);
                        UpdateMenu();
                    });
                    item.DropDownItems.Add(resetItem);
                    menu.Items.Add(item);
                }
                
                menu.Items.Add(new ToolStripSeparator());
                menu.Items.Add("Reset All", null, (s, e) => {
                    foreach (var hWnd in _trackedWindows) WindowHelper.ResetWindow(hWnd);
                    _trackedWindows.Clear();
                    UpdateMenu();
                });
                menu.Items.Add(new ToolStripSeparator());
            }

            menu.Items.Add("Exit", null, (s, e) => ExitThread());
        }

        protected override void ExitThreadCore()
        {
            // Reset all tracked windows on exit
            foreach (var hWnd in _trackedWindows)
            {
                WindowHelper.ResetWindow(hWnd);
            }
            _trackedWindows.Clear();

            _trayIcon.Visible = false;
            _hiddenWindow.Dispose();
            base.ExitThreadCore();
        }
    }

    public class BetterOnTopWindow : NativeWindow, IDisposable
    {
        private const int WM_HOTKEY = 0x0312;
        private const int HOTKEY_ID_T = 0x1001;
        private const int HOTKEY_ID_W = 0x1002;
        private const int HOTKEY_ID_G = 0x1003;

        public event Action<IntPtr>? WindowChanged;

        public BetterOnTopWindow()
        {
            CreateHandle(new CreateParams { Caption = "BetterOnTopProcessor" });
            
            uint modifiers = WindowHelper.MOD_CONTROL | WindowHelper.MOD_ALT;
            
            WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_T, modifiers, 0x54); // T
            WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_W, modifiers, 0x57); // W
            WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_G, modifiers, 0x47); // G
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY)
            {
                IntPtr hWnd = WindowHelper.GetForegroundWindow();
                if (hWnd != IntPtr.Zero)
                {
                    SystemSounds.Asterisk.Play();
                    int id = m.WParam.ToInt32();
                    
                    if (id == HOTKEY_ID_T) WindowHelper.ToggleTopmost(hWnd);
                    else if (id == HOTKEY_ID_W) WindowHelper.ToggleOpacity(hWnd);
                    else if (id == HOTKEY_ID_G) WindowHelper.ToggleClickthrough(hWnd);
                    
                    WindowChanged?.Invoke(hWnd);
                }
            }
            base.WndProc(ref m);
        }

        public void Dispose()
        {
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_T);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_W);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_G);
            DestroyHandle();
        }
    }
}
