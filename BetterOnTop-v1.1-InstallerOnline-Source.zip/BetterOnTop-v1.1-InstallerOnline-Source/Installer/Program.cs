using System;
using System.Linq;
using System.Windows.Forms;

namespace BetterOnTopInstaller
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            if (args.Contains("/uninstall"))
            {
                if (MessageBox.Show("Are you sure you want to uninstall BetterOnTop?", "Uninstall BetterOnTop", MessageBoxButtons.YesNo, MessageBoxIcon.Information) == DialogResult.Yes)
                {
                    InstallerForm.PerformUninstall();
                }
                return;
            }

            ApplicationConfiguration.Initialize();
            Application.Run(new InstallerForm());
        }
    }
}
