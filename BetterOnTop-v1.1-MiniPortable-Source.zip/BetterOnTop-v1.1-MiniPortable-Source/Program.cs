using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Media;
using System.Linq;

namespace BetterOnTop
{
    public class Program
    {
        [STAThread]
        public static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            Application.Run(new BetterOnTopContext());
        }
    }

    public class BetterOnTopContext : ApplicationContext
    {
        private NotifyIcon _trayIcon;
        private BetterOnTopWindow _hiddenWindow;
        private HashSet<IntPtr> _trackedWindows = new HashSet<IntPtr>();
        private WindowPositionManager _posManager;

        public BetterOnTopContext()
        {
            try
            {
                _posManager = new WindowPositionManager();
                _posManager.SettingsChanged += () => { /* Handle background updates if needed */ };

                _hiddenWindow = new BetterOnTopWindow(_posManager);
                _hiddenWindow.WindowChanged += OnWindowChanged;

                _trayIcon = new NotifyIcon
                {
                    Text = "BetterOnTop v1.1",
                    Icon = SystemIcons.Shield, 
                    ContextMenuStrip = new ContextMenuStrip(),
                    Visible = true
                };
                
                // This ensures the menu is built/refreshed EVERY time you right-click
                _trayIcon.ContextMenuStrip.Opening += (s, e) => {
                    UpdateMenu();
                    e.Cancel = false; // Ensure it opens
                };
                
                UpdateMenu(); // Initial build
                
                _trayIcon.ShowBalloonTip(3000, "BetterOnTop v1.1", "Hotkeys Active.\nCtrl+Alt+T/W/U/L", ToolTipIcon.Info);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Startup Error: {ex.Message}");
            }
        }

        private void OnWindowChanged(IntPtr hWnd)
        {
            _trackedWindows.Add(hWnd);
            if (hWnd != IntPtr.Zero)
            {
                _trackedWindows.Add(hWnd);
                UpdateMenu();
            }
        }

        private ToolStripMenuItem CreateRunAtStartupMenuItem()
        {
            var item = new ToolStripMenuItem("Run at Startup");
            item.Checked = IsRunAtStartupEnabled();
            item.Click += (s, e) => {
                bool enabled = !item.Checked;
                SetRunAtStartup(enabled);
                item.Checked = enabled;
            };
            return item;
        }

        private bool IsRunAtStartupEnabled()
        {
            using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", false))
            {
                return key?.GetValue("BetterOnTop") != null;
            }
        }

        private void SetRunAtStartup(bool enabled)
        {
            using (var key = Microsoft.Win32.Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
            {
                if (key == null) return;
                if (enabled)
                    key.SetValue("BetterOnTop", $"\"{Application.ExecutablePath}\"");
                else
                    key.DeleteValue("BetterOnTop", false);
            }
        }

        private void UpdateMenu()
        {
            try
            {
                var menu = _trayIcon?.ContextMenuStrip;
                if (menu == null) return;
                menu.Items.Clear();

                // --- Configuration ---
                menu.Items.Add(CreateRunAtStartupMenuItem());
                menu.Items.Add(new ToolStripLabel("BetterOnTop v1.1 Active") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 7, FontStyle.Italic) });
                menu.Items.Add(new ToolStripSeparator());

                // --- Modified Windows (T/W/U) ---
                var openTracked = _trackedWindows.Where(h => WindowHelper.GetWindowTitle(h) != "Unknown Window").ToList();
                if (openTracked.Count > 0)
                {
                    menu.Items.Add(new ToolStripLabel("Modified Windows:") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Bold) });
                    foreach (var hWnd in openTracked)
                    {
                        var status = WindowHelper.GetWindowStatus(hWnd);
                        bool isLocked = _posManager.IsRemembered(hWnd);
                        string title = WindowHelper.GetWindowTitle(hWnd);
                        
                        string t = status.IsTopmost ? "T" : "·";
                        string w = status.IsLayered ? "W" : "·";
                        string u = status.IsTransparent ? "U" : "·";
                        string l = isLocked ? "L" : "·";
                        
                        var item = new ToolStripMenuItem($"[{t}{w}{u}{l}] {title}");
                        var resetItem = new ToolStripMenuItem("Reset All Effects", null, (s, e) => {
                            WindowHelper.ResetWindow(hWnd);
                            _trackedWindows.Remove(hWnd);
                            UpdateMenu();
                        });
                        item.DropDownItems.Add(resetItem);
                        menu.Items.Add(item);
                    }
                    menu.Items.Add("Reset All Modified", null, (s, e) => {
                        foreach (var hWnd in openTracked) WindowHelper.ResetWindow(hWnd);
                        _trackedWindows.Clear();
                        UpdateMenu();
                    });
                    menu.Items.Add(new ToolStripSeparator());
                }

                // --- Active Remembered Windows (L) ---
                var activeLocked = _posManager.GetActiveRememberedWindows();
                if (activeLocked.Count > 0)
                {
                    menu.Items.Add(new ToolStripLabel("Active Saved Positions:") { Enabled = false, Font = new Font(FontFamily.GenericSansSerif, 8, FontStyle.Bold) });
                    foreach (var (title, key, hWnd) in activeLocked)
                    {
                        var item = new ToolStripMenuItem($"[L] {title}");
                        var forgetItem = new ToolStripMenuItem("Stop Remembering", null, (s, e) => {
                            _posManager.ForgetWindow(key);
                        });
                        item.DropDownItems.Add(forgetItem);
                        menu.Items.Add(item);
                    }
                    menu.Items.Add("Forget All Positions", null, (s, e) => {
                        if (MessageBox.Show("Delete ALL saved positions?", "BetterOnTop", MessageBoxButtons.YesNo) == DialogResult.Yes)
                        {
                            _posManager.ClearAll();
                        }
                    });
                    menu.Items.Add(new ToolStripSeparator());
                }

                if (openTracked.Count == 0 && activeLocked.Count == 0)
                {
                    menu.Items.Add(new ToolStripMenuItem("No Active Modifications") { Enabled = false });
                    menu.Items.Add(new ToolStripSeparator());
                }

                menu.Items.Add("Exit BetterOnTop", null, (s, e) => ExitThread());
            }
            catch (Exception ex)
            {
                var menu = _trayIcon?.ContextMenuStrip;
                if (menu == null) return;
                menu.Items.Clear();
                menu.Items.Add(new ToolStripMenuItem($"Menu Load Error: {ex.Message}") { Enabled = false });
                menu.Items.Add("Exit BetterOnTop", null, (s, e) => ExitThread());
            }
        }

        protected override void ExitThreadCore()
        {
            foreach (var hWnd in _trackedWindows)
            {
                WindowHelper.ResetWindow(hWnd);
            }
            _trackedWindows.Clear();

            if (_trayIcon != null) _trayIcon.Visible = false;
            _hiddenWindow.Dispose();
            _posManager.Dispose();
            base.ExitThreadCore();
        }
    }

    public class BetterOnTopWindow : NativeWindow, IDisposable
    {
        private const int WM_HOTKEY = 0x0312;
        private const int HOTKEY_ID_T = 0x1001;
        private const int HOTKEY_ID_W = 0x1002;
        private const int HOTKEY_ID_U = 0x1003;
        private const int HOTKEY_ID_L = 0x1004;

        private WindowPositionManager _posManager;

        public event Action<IntPtr>? WindowChanged;

        public BetterOnTopWindow(WindowPositionManager posManager)
        {
            _posManager = posManager;
            CreateHandle(new CreateParams { Caption = "BetterOnTopProcessorV1_1" });
            
            uint modifiers = WindowHelper.MOD_CONTROL | WindowHelper.MOD_ALT;
            
            bool r1 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_T, modifiers, 0x54); // T
            bool r2 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_W, modifiers, 0x57); // W
            bool r3 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_U, modifiers, 0x55); // U
            bool r4 = WindowHelper.RegisterHotKey(Handle, HOTKEY_ID_L, modifiers, 0x4C); // L

            if (r1 && r2 && r3 && r4)
            {
                SystemSounds.Hand.Play(); 
            }
            else
            {
                SystemSounds.Exclamation.Play(); 
            }
        }

        protected override void WndProc(ref Message m)
        {
            if (m.Msg == WM_HOTKEY)
            {
                IntPtr hWnd = WindowHelper.GetForegroundWindow();
                if (hWnd != IntPtr.Zero)
                {
                    SystemSounds.Asterisk.Play();
                    int id = m.WParam.ToInt32();
                    
                    if (id == HOTKEY_ID_T) WindowHelper.ToggleTopmost(hWnd);
                    else if (id == HOTKEY_ID_W) WindowHelper.ToggleOpacity(hWnd);
                    else if (id == HOTKEY_ID_U) WindowHelper.ToggleClickthrough(hWnd);
                    else if (id == HOTKEY_ID_L) _posManager.ToggleMemory(hWnd);
                    
                    WindowChanged?.Invoke(hWnd);
                }
            }
            base.WndProc(ref m);
        }

        public void Dispose()
        {
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_T);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_W);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_U);
            WindowHelper.UnregisterHotKey(Handle, HOTKEY_ID_L);
            DestroyHandle();
        }
    }
}
