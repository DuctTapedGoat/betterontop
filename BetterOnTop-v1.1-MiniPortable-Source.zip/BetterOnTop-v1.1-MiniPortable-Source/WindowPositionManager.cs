using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Text.Json;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Linq;

namespace BetterOnTop
{
    public partial class WindowPositionManager : IDisposable
    {
        private const uint EVENT_OBJECT_LOCATIONCHANGE = 0x800B;
        private const uint EVENT_OBJECT_SHOW = 0x8002;
        private const uint WINEVENT_OUTOFCONTEXT = 0;
        private const uint WINEVENT_SKIPOWNPROCESS = 2;

        private delegate void WinEventDelegate(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime);

        [LibraryImport("user32.dll")]
        private static partial IntPtr SetWinEventHook(uint eventMin, uint eventMax, IntPtr hmodWinEventProc, WinEventDelegate lpfnWinEventProc, uint idProcess, uint idThread, uint dwFlags);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool UnhookWinEvent(IntPtr hWinEventHook);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool GetWindowPlacement(IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool SetWindowPlacement(IntPtr hWnd, ref WINDOWPLACEMENT lpwndpl);

        [LibraryImport("user32.dll", EntryPoint = "GetWindowTextW", StringMarshalling = StringMarshalling.Utf16)]
        private static partial int GetWindowText(IntPtr hWnd, [Out] char[] lpString, int nMaxCount);

        [LibraryImport("user32.dll", EntryPoint = "GetClassNameW", StringMarshalling = StringMarshalling.Utf16)]
        private static partial int GetClassName(IntPtr hWnd, [Out] char[] lpClassName, int nMaxCount);

        [LibraryImport("user32.dll")]
        private static partial uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);

        [LibraryImport("kernel32.dll", SetLastError = true)]
        private static partial IntPtr OpenProcess(uint dwDesiredAccess, [MarshalAs(UnmanagedType.Bool)] bool bInheritHandle, uint dwProcessId);

        [LibraryImport("kernel32.dll", EntryPoint = "QueryFullProcessImageNameW", StringMarshalling = StringMarshalling.Utf16, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool QueryFullProcessImageName(IntPtr hProcess, int dwFlags, [Out] char[] lpExeName, ref int lpdwSize);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
        private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

        [LibraryImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool IsWindowVisible(IntPtr hWnd);

        [LibraryImport("kernel32.dll", SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static partial bool CloseHandle(IntPtr hObject);

        [StructLayout(LayoutKind.Sequential)]
        private struct WINDOWPLACEMENT
        {
            public int length;
            public int flags;
            public int showCmd;
            public POINT ptMinPosition;
            public POINT ptMaxPosition;
            public RECT rcNormalPosition;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct POINT
        {
            public int x;
            public int y;
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int left;
            public int top;
            public int right;
            public int bottom;
        }

        private class WindowSettings
        {
            public string ProcessName { get; set; } = string.Empty;
            public string Title { get; set; } = string.Empty;
            public int Left { get; set; }
            public int Top { get; set; }
            public int Right { get; set; }
            public int Bottom { get; set; }
            public int ShowCmd { get; set; }
            public bool IsLocked { get; set; }
        }

        private IntPtr _locationHook;
        private IntPtr _showHook;
        private WinEventDelegate _eventDelegate;
        private Dictionary<string, WindowSettings> _memory = new Dictionary<string, WindowSettings>();
        private string _configPath;

        public event Action? SettingsChanged;

        public WindowPositionManager()
        {
            _configPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "BetterOnTop", "window_positions.json");
            LoadSettings();

            _eventDelegate = new WinEventDelegate(WinEventProc);
            
            _locationHook = SetWinEventHook(EVENT_OBJECT_LOCATIONCHANGE, EVENT_OBJECT_LOCATIONCHANGE, IntPtr.Zero, _eventDelegate, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
            _showHook = SetWinEventHook(EVENT_OBJECT_SHOW, EVENT_OBJECT_SHOW, IntPtr.Zero, _eventDelegate, 0, 0, WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS);
        }

        private void WinEventProc(IntPtr hWinEventHook, uint eventType, IntPtr hwnd, int idObject, int idChild, uint dwEventThread, uint dwmsEventTime)
        {
            if (idObject != 0 || hwnd == IntPtr.Zero) return;

            if (eventType == EVENT_OBJECT_LOCATIONCHANGE)
            {
                HandleLocationChange(hwnd);
            }
            else if (eventType == EVENT_OBJECT_SHOW)
            {
                HandleShow(hwnd);
            }
        }

        private void HandleLocationChange(IntPtr hwnd)
        {
            string? appKey = GetAppKey(hwnd);
            if (appKey == null) return;

            // Only update if we are already tracking this window or if it's explicitly locked
            if (_memory.TryGetValue(appKey, out var setting))
            {
                WINDOWPLACEMENT wp = new WINDOWPLACEMENT();
                wp.length = Marshal.SizeOf(wp);
                if (GetWindowPlacement(hwnd, ref wp))
                {
                    setting.Left = wp.rcNormalPosition.left;
                    setting.Top = wp.rcNormalPosition.top;
                    setting.Right = wp.rcNormalPosition.right;
                    setting.Bottom = wp.rcNormalPosition.bottom;
                    setting.ShowCmd = wp.showCmd;
                    setting.Title = GetWindowTitle(hwnd);

                    SaveSettings();
                }
            }
        }

        private void HandleShow(IntPtr hwnd)
        {
            string? appKey = GetAppKey(hwnd);
            if (appKey == null) return;

            if (_memory.TryGetValue(appKey, out var setting) && setting.IsLocked)
            {
                WINDOWPLACEMENT wp = new WINDOWPLACEMENT();
                wp.length = Marshal.SizeOf(wp);
                if (GetWindowPlacement(hwnd, ref wp))
                {
                    wp.rcNormalPosition.left = setting.Left;
                    wp.rcNormalPosition.top = setting.Top;
                    wp.rcNormalPosition.right = setting.Right;
                    wp.rcNormalPosition.bottom = setting.Bottom;
                    wp.showCmd = setting.ShowCmd == 2 ? 1 : setting.ShowCmd;

                    SetWindowPlacement(hwnd, ref wp);
                }
            }
        }

        public void ToggleMemory(IntPtr hwnd)
        {
            string? appKey = GetAppKey(hwnd);
            if (appKey == null) return;

            if (_memory.TryGetValue(appKey, out var setting))
            {
                _memory.Remove(appKey);
            }
            else
            {
                WINDOWPLACEMENT wp = new WINDOWPLACEMENT();
                wp.length = Marshal.SizeOf(wp);
                if (GetWindowPlacement(hwnd, ref wp))
                {
                    _memory[appKey] = new WindowSettings
                    {
                        ProcessName = appKey,
                        Title = GetWindowTitle(hwnd),
                        Left = wp.rcNormalPosition.left,
                        Top = wp.rcNormalPosition.top,
                        Right = wp.rcNormalPosition.right,
                        Bottom = wp.rcNormalPosition.bottom,
                        ShowCmd = wp.showCmd,
                        IsLocked = true
                    };
                }
            }
            SaveSettings();
            SettingsChanged?.Invoke();
        }

        public bool IsRemembered(IntPtr hwnd)
        {
            string? appKey = GetAppKey(hwnd);
            return appKey != null && _memory.ContainsKey(appKey);
        }

        public List<(string Title, string Key, IntPtr hWnd)> GetActiveRememberedWindows()
        {
            var active = new List<(string Title, string Key, IntPtr hWnd)>();
            EnumWindows((hWnd, lParam) =>
            {
                if (!IsWindowVisible(hWnd)) return true;
                string? appKey = GetAppKey(hWnd);
                if (appKey != null && _memory.ContainsKey(appKey))
                {
                    string title = GetWindowTitle(hWnd);
                    if (string.IsNullOrEmpty(title)) title = Path.GetFileName(appKey.Split('|')[0]);
                    active.Add((title, appKey, hWnd));
                }
                return true;
            }, IntPtr.Zero);
            return active;
        }

        public void ForgetWindow(string appKey)
        {
            if (_memory.Remove(appKey))
            {
                SaveSettings();
                SettingsChanged?.Invoke();
            }
        }

        public void ClearAll()
        {
            _memory.Clear();
            SaveSettings();
            SettingsChanged?.Invoke();
        }

        private string? GetAppKey(IntPtr hwnd)
        {
            uint pid;
            GetWindowThreadProcessId(hwnd, out pid);
            if (pid == 0) return null;

            string? processPath = null;
            IntPtr hProcess = OpenProcess(0x1000 /* PROCESS_QUERY_LIMITED_INFORMATION */, false, pid);
            if (hProcess != IntPtr.Zero)
            {
                char[] buffer = new char[1024];
                int size = buffer.Length;
                if (QueryFullProcessImageName(hProcess, 0, buffer, ref size))
                {
                    processPath = new string(buffer, 0, size);
                }
                CloseHandle(hProcess);
            }

            if (string.IsNullOrEmpty(processPath) || processPath.EndsWith("explorer.exe", StringComparison.OrdinalIgnoreCase))
                return null;

            char[] className = new char[256];
            int classLength = GetClassName(hwnd, className, className.Length);
            string classStr = new string(className, 0, classLength);

            return $"{processPath}|{classStr}";
        }

        private string GetWindowTitle(IntPtr hwnd)
        {
            char[] buffer = new char[256];
            int length = GetWindowText(hwnd, buffer, buffer.Length);
            return new string(buffer, 0, length);
        }

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(_configPath))
                {
                    string json = File.ReadAllText(_configPath);
                    _memory = JsonSerializer.Deserialize<Dictionary<string, WindowSettings>>(json) ?? new Dictionary<string, WindowSettings>();
                }
            }
            catch { }
        }

        private void SaveSettings()
        {
            try
            {
                string? dir = Path.GetDirectoryName(_configPath);
                if (dir != null && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                string json = JsonSerializer.Serialize(_memory, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(_configPath, json);
            }
            catch { }
        }

        public void Dispose()
        {
            if (_locationHook != IntPtr.Zero) UnhookWinEvent(_locationHook);
            if (_showHook != IntPtr.Zero) UnhookWinEvent(_showHook);
        }
    }
}
